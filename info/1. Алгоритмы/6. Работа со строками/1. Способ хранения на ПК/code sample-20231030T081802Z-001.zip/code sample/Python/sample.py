
def code_to_ASCII(text):
    code_points = []
    for sym in text:
        code_point = ord(sym)
        if code_point > 128:
            raise ValueError("String contains erroneous characters ")
        code_points.append(code_point)
    return bytes(code_points)


def decode_from_ASCII(byte_sequince):
    result = ""
    for b in byte_sequince:
        result = result+chr(b)
    return result


def save_to_ascii_file(file_name, text):
    with open(file_name, "wb") as f:
        f.write(code_to_ASCII(text))


def load_from_ascii_file(file_name):
    with open(file_name, "rb") as f:
        byte_text = f.read()
    return decode_from_ASCII(byte_text)


text = "Hello world"

file_name = "hello.txt"

save_to_ascii_file(file_name, text)

read_text = load_from_ascii_file(file_name)

print(read_text)
