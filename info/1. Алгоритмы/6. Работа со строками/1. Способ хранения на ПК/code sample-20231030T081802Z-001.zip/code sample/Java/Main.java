package sample;

import java.io.File;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String text = "Hello world ☺";

		File file = new File("hello.txt");

		try {
			UTF8Coder.saveToUTF8File(text, file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String result = "";

		try {
			result = UTF8Coder.loadFromUTF8File(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(result);

	}

}
