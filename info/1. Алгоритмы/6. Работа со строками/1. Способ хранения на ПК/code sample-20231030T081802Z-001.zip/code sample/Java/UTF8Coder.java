package sample;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class UTF8Coder {

	// -------------Coder method start------------------

	public static int numberOfBytes(int codePoint) {
		if (codePoint <= 0x7F) {
			return 1;
		} else if (codePoint <= 0x7FF) {
			return 2;
		} else if (codePoint <= 0xFFFF) {
			return 3;
		}
		return 4;
	}

	public static byte[] codeSymbol(int codePoint) {
		int numberOfBytes = numberOfBytes(codePoint);
		if (numberOfBytes == 1) {
			return new byte[] { (byte) codePoint };
		}
		byte[] result = new byte[numberOfBytes];
		int mask = 0b111111;
		int firstByte = 0b10000000;
		for (int i = numberOfBytes - 1; i > 0; i--) {
			result[i] = (byte) ((codePoint & mask) | 0b10000000);
			codePoint = codePoint >> 6;
			firstByte = (firstByte >> 1) | firstByte;
		}
		result[0] = (byte) (firstByte | codePoint);
		return result;
	}

	public static byte[] codeToUTF8(String text) throws IOException {
		ByteArrayOutputStream os = new ByteArrayOutputStream();
		char[] symbols = text.toCharArray();
		for (int i = 0; i < symbols.length; i++) {
			int codePoint = Character.codePointAt(symbols, i);
			os.write(codeSymbol(codePoint));
		}
		return os.toByteArray();
	}

	public static void saveToUTF8File(String text, File file) throws IOException {
		try (OutputStream os = new FileOutputStream(file)) {
			os.write(0b11101111);
			os.write(0b10111011);
			os.write(0b10111111);
			os.write(codeToUTF8(text));
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
	}

	/// -------------------Decoder methods start -------------------------------

	public static int numberOfNextBytes(byte firstByte) {
		int nb = 1;
		if ((firstByte & 0b10000000) == 0) {
			return 1;
		}
		for (int i = 1; i <= 4; i++) {
			firstByte = (byte) (firstByte << 1);
			if ((firstByte & 0b10000000) == 0) {
				nb = i;
				break;
			}
		}
		return nb;
	}

	public static int getSymbolCodePoint(byte[] byteArray, int start, int end) {
		if (start == end) {
			return byteArray[start];
		}
		int result = (255 & byteArray[start]) & ((1 << (6 - (end - start))) - 1);
		for (int i = start + 1; i <= end; i++) {
			result = result << 6;
			result = result | ((255 & byteArray[i]) & 0b111111);
		}
		return result;
	}

	public static String decodeFromUTF8(byte[] bytes) {
		int start = 0;
		int end = start + numberOfNextBytes(bytes[start]) - 1;
		String result = Character.toString(getSymbolCodePoint(bytes, start, end));
		for (;;) {
			start = end + 1;
			if (start >= bytes.length) {
				break;
			}
			end = start + numberOfNextBytes(bytes[start]) - 1;
			result += Character.toString(getSymbolCodePoint(bytes, start, end));
		}
		return result;
	}

	public static String loadFromUTF8File(File file) throws IOException {
		try (InputStream is = new FileInputStream(file)) {
			byte[] bytes = new byte[is.available() - 3];
			byte[] checkEncoding = new byte[3];
			is.read(checkEncoding);
			if ((255 & checkEncoding[0]) != 0b11101111 || (255 & checkEncoding[1]) != 0b10111011
					|| (255 & checkEncoding[2]) != 0b10111111) {
				throw new IllegalArgumentException("This is not a supported encoding ");
			}
			is.read(bytes);
			return decodeFromUTF8(bytes);
		} catch (IOException e) {
			throw e;
		}
	}

}
